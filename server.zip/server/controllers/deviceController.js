const uuid = require('uuid')
const path = require('path')
const {Device, DeviceInfo, BasketDevice} = require('../models/models')
const ApiError = require('../error/ApiError')

class DeviceController {
    async create(req, res, next) {
        try {
            let {name, price, brandId, typeId, info} = req.body
            const {img} = req.files
            let fileName = uuid.v4() + '.jpg' // Функция uuid.v4 генерирует рандомный айди

            // Перемещение файла с заданным именем в нужную нам папку
            await img.mv(path.resolve(__dirname, '..', 'static', fileName)) // Функция resolve адаптирует путь под операционную систему

            const device = await Device.create({name, price, brandId, typeId, img: fileName}) // Создание нового девайса на сервере

            if (info) {
                info = JSON.parse(info) // Превращение строки в объект
                info.forEach(i =>
                    DeviceInfo.create({
                        title: i.title,
                        description: i.description,
                        deviceId: device.id
                    })
                )
            }
            return res.json(device)
        } catch (e) {
            next(ApiError.badRequest(e.message))
        }
    }

    async getAll(req, res) {
        let {brandId, typeId, limit, page} = req.query // Получение бренда и типа из строки запроса
        page = page || 1
        limit = limit || 9
        let offset = page * limit - limit
        let devices
        if (!brandId && !typeId) {
            devices = await Device.findAndCountAll({limit, offset})
        }
        if (brandId && !typeId) {
            devices = await Device.findAndCountAll({where: {brandId}, limit, offset})
        }
        if (!brandId && typeId) {
            devices = await Device.findAndCountAll({where: {typeId}, limit, offset})
        }
        if (brandId && typeId) {
            devices = await Device.findAndCountAll({where: {brandId, typeId}, limit, offset})
        }
        return res.json(devices)
    }

    async getOne(req, res) {
        const {id} = req.params
        const device = await Device.findOne(
            {
                where: {id},
                // include: [{model: DeviceInfo, as: 'info'}] // Подгрузка доп характеристик
            },
        )
        return res.json(device)
    }

    async remove(req, res) {
        const {id} = req.body.device
        const deviceId = id
        const device = await BasketDevice.destroy({
            where: {deviceId}
        })
        const removableDevice = await Device.destroy({
            where: {id}
        })
        res.json(removableDevice)
    }
}

module.exports = new DeviceController()